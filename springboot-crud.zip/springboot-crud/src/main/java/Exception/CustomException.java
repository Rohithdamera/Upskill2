package Exception;

public class CustomException {
	String data="User Not Found Please check the data";
	public String custom(String data) {
		this.data=data;
		return data;
		
	}

}
